/*
* robot.h is the class file that contains all the declarations of the functions. 
  It contains constructors, actions, an operator overload,
* and private data types.
* 
* The constructor takes in arguments from the point class and then runs it through the recursive function.
* 
* FindTreasurePaths is the recursion function that moves the robot North, South, East, and West
* It creates shortest distance unique paths and and counts how many paths there are total. 
* Steps in a one direction (N, S, E, W) are limited by max_distance_ that the user gives in the command prompt 
* until it reaches the treasure's coordinates. 
*/
#ifndef ROBOT_H
#define ROBOT_H
#include <iostream>
#include <string>
#include "point.h"
using namespace std;

class Robot
{
public:
	//Constructors
	Robot();
	Robot(Point point, int max_distance);
	~Robot();

	//Actions
	int FindTreasurePaths(int current_x_r, int current_y_r, int treasure_x, int treasure_y, string path_way);
	
	//Operator Overload
	friend ostream& operator<<(ostream& out_stream, const Robot& robot);

private:
	//Private data types
	//For Moving Robot
	int max_distance_ = 0;
	int north_ = 0;
	int south_ = 0;
	int west_ = 0;
	int east_ = 0;

	//Number of paths total
	int number_paths_ = 0;
};
#endif
