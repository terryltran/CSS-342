/*
*   CSS 342B - Data Structures, Algorithms, and Discrete Mathematics I
*   Program 2: Recursion 
*   Part 2: The Greedy Robot Program
*   Name: Terry Tran
* 
*   This is the driver
*/
#include <iostream>
#include "robot.h"
using namespace std; 

int main(int argc, char* argv[])
{
    if (argc != 6)
    {
        cout << "Invalid amount of arguments. Please input 5 integers." << endl;
    }
    else
    {
        Robot robot((Point(atoi(argv[1]), (atoi(argv[2])), (atoi(argv[3])), (atoi(argv[4])))), atoi(argv[5]));
        if (atoi(argv[1]) == atoi(argv[3]) && atoi(argv[2]) == atoi(argv[4]))
        {
            cout << "You are at the same location as the treasure." << endl;
            cout << "Number of Paths: 0" << endl;
        }
        else
        {
            cout << robot << endl;
        }
    }
}