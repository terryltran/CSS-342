//Implementation of Point class (point.h)
#include "point.h"

Point::Point()
{
}

Point::Point(int x_robot, int y_robot, int x_treasure, int y_treasure)
{
	x_r_ = x_robot;
	y_r_ = y_robot;
	x_t_ = x_treasure;
	y_t_ = y_treasure;
}

Point::~Point()
{
}

int Point::getRobotXCoordinate() const
{
	return x_r_;
}

int Point::getRobotYCoordinate() const
{
	return y_r_;
}

int Point::getTreasureXCoordinate() const
{
	return x_t_;
}

int Point::getTreasureYCoordinate() const
{
	return y_t_;
}
