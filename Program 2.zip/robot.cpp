//Implementation of Robot class (robot.h)
#include "robot.h"

Robot::Robot()
{
}

Robot::Robot(Point point, int max_distance)
{
	max_distance_ = max_distance;
	north_ = max_distance;
	south_ = max_distance;
	east_ = max_distance;
	west_ = max_distance;
	number_paths_ = FindTreasurePaths(point.getRobotXCoordinate(), point.getRobotYCoordinate(), point.getTreasureXCoordinate(), point.getTreasureYCoordinate(), "");
}

Robot::~Robot()
{
}


int Robot::FindTreasurePaths(int current_x_r, int current_y_r, int treasure_x, int treasure_y,  string path_way)
{
	//New Unique Path and Print it out
	if (current_x_r == treasure_x && current_y_r == treasure_y)
	{
		cout << path_way << endl;
		return 1;
	}

	int path_count = 0;
	//Move South
	if (current_y_r > treasure_y && south_ != 0)
	{
		south_--;
		north_ = max_distance_;
		west_ = max_distance_;
		east_ = max_distance_;
		path_count += FindTreasurePaths(current_x_r, current_y_r - 1, treasure_x, treasure_y, path_way + "S");
	}
	//Move North
	if (current_y_r < treasure_y && north_ != 0)
	{
		south_ = max_distance_;
		north_--;
		west_ = max_distance_;
		east_ = max_distance_;
		path_count += FindTreasurePaths(current_x_r, current_y_r + 1, treasure_x, treasure_y, path_way + "N");
	}
	//Move West
	if (current_x_r > treasure_x && west_ != 0)
	{
		south_ = max_distance_;
		north_ = max_distance_;
		west_--;
		east_ = max_distance_;
		path_count += FindTreasurePaths(current_x_r - 1, current_y_r, treasure_x, treasure_y, path_way + "W");
	}
	//Move East
	if (current_x_r < treasure_x && east_ != 0)
	{
		south_ = max_distance_;
		north_ = max_distance_;
		west_ = max_distance_;
		east_--;
		path_count += FindTreasurePaths(current_x_r + 1, current_y_r, treasure_x, treasure_y, path_way + "E");
	}
	return path_count;
}

ostream& operator<<(ostream& out_stream, const Robot& robot)
{
	out_stream << "Number of Paths: " << robot.number_paths_ << endl;
	return out_stream;
}
