/*
	point.h is a class file that gets user arguments from the command prompt 
	and sets the global variables x_r_ (robot x-coordinate), y_r_ (robot y-coordinate),
	x_t_ (treasure x-coordinate), and y_t_ (treasure y-coordinate).
*/
#pragma once
class Point
{
public:
	Point();
	Point(int x_robot, int y_robot, int x_treasure, int y_treasure);
	~Point();

	int getRobotXCoordinate() const;
	int getRobotYCoordinate() const;
	int getTreasureXCoordinate() const;
	int getTreasureYCoordinate() const;

private:
	//Coordinates of Robot
	int x_r_ = 0;
	int y_r_ = 0;

	//Coordinates of Treasure
	int x_t_ = 0;
	int y_t_ = 0;
};

