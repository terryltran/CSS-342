/*
*   CSS 342B - Data Structures, Algorithms, and Discrete Mathematics I
*   Program 2: Recursion
*   Part 1: Catalan
*   Name: Terry Tran
*/
#include <iostream>
#include <string>

using namespace std;

int Catalan(int number);

int main(int argc, char* argv[])
{
    if (argc != 2)
    {
        cout << "Please give an argument in the form: catalan *insert number* " << endl;
    }
    int value = atoi(argv[1]);
    cout << "Catalan Number of the given value " << value << " is: " << Catalan(value) << "." << endl;
}

int Catalan(int number)
{
    if (number < 0)
    {
        cout << "Your number cannot be lower than zero." << endl;
        return 0;
    }
    if (number <= 1)
    {
        return 1;
    }

    int answer = 0;
    for (int i = 0; i < number; i++)
    {
        answer += Catalan(i) * Catalan(number - i - 1);
    }
    return answer;
}
