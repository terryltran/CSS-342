/*
	CSS 342 B - Data Structures, Algorithms, and Discrete Mathematics I
	Name: Terry Tran
	Program 3: Linked List - List342 class

	Description: 
	This templatized List342 class creates a Linked List of the objects put into the driver.
	It has many functions as inserting and removing an item into a list, merging together
	two lists together, delete a list, looking for a specific item in the list, and check
	if the list is empty. The implementation of the functions declared in the class are 
	below the class. 

*/
#ifndef LIST342_H
#define LIST342_H
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;
template<class ItemType>
class List342
{
public:
	// Default Constructor, Copy Constructor, and Destructor
	List342();
	List342(const List342& list);
	~List342();
	
	// Actions
	bool BuildList(string fileName);
	bool Insert(ItemType* obj);
	bool Remove(ItemType target, ItemType& result);
	bool Peek(ItemType target, ItemType& result) const;
	bool isEmpty() const;
	void DeleteList();
	bool Merge(List342& list1);

	// Operator Overloads
	friend ostream& operator<<(ostream& out_stream, const List342& list)
	{
		Node* new_node = list.head_;
		while (new_node != nullptr)
		{
			ItemType temp = *new_node->data;
			out_stream << temp;
			new_node = new_node->next;
		}
		return out_stream;
	}
	List342 operator+(const List342& list) const;
	List342 operator+=(const List342& list);
	bool operator==(const List342& list) const;
	bool operator!=(const List342& list) const;
	List342& operator=(const List342& list);

private:
	// For Nodes
	struct Node
	{
		ItemType* data = nullptr;
		Node* next = nullptr;
	};
	// Private Data Type
	Node* head_ = nullptr;
};

// Function Implementations

template<class ItemType>
List342<ItemType>::List342()
{
}

template<class ItemType>
List342<ItemType>::List342(const List342& list)
{
	head_ = nullptr;
	*this = list;
}

template<class ItemType>
List342<ItemType>::~List342()
{
	this->DeleteList();
}

template<class ItemType>
bool List342<ItemType>::BuildList(string file_name)
{
	ifstream in_file;
	in_file.open(file_name);
	if (in_file.is_open())
	{
		while (!in_file.eof()) // Doesn't stop still file is fully read and inserted
		{
			ItemType* item = new ItemType();
			in_file >> *item;
			Insert(item);
		}
		return true;
		in_file.close();
	}
	else
	{
		cout << "File: " << file_name << " not found." << endl;
		return false;
	}
}
template<class ItemType>
bool List342<ItemType>::Insert(ItemType* obj)
{
	if (head_ == nullptr)
	{
		head_ = new Node;
		head_->data = obj;
		head_->next = nullptr;
		return true;
	}
	if (*obj < *head_->data)
	{
		Node* ins_node = new Node;
		ins_node->data = obj;
		ins_node->next = head_;
		head_ = ins_node;
		return true;
	}
	// No duplicates allowed
	if (*obj == *head_->data)
	{
		return false;
	}

	Node* p_node = head_;
	while ((p_node->next != nullptr) && (*(p_node->next)->data < *obj))
	{
		p_node = p_node->next;
	}
	if ((p_node->next != nullptr) && (*(p_node->next)->data == *obj))
	{
		return false;
	}
	Node* ins_node = new Node;
	ins_node->data = obj;
	ins_node->next = p_node->next;
	p_node->next = ins_node;
	return true;
}
template<class ItemType>
bool List342<ItemType>::Remove(ItemType target, ItemType& result)
{
	// If the list is empty
	if (isEmpty())
	{
		return false;
	}
	// If the head node's item is equal to the target
	if (*head_->data == target)
	{
		Node* temp = head_;
		head_ = head_->next;
		result = target;
		delete temp;
		temp = nullptr;
		return true;
	}
	// Searches for the right node that the target is in, and if the item is not in the list, it returns false
	Node* p_node = head_;
	while ((p_node->next != nullptr) && (*(p_node->next)->data < target))
	{
		p_node = p_node->next;
	}
	if ((p_node->next == nullptr) || (*(p_node->next)->data != target))
	{
		return false;
	}
	Node* temp = p_node->next;
	p_node->next = p_node->next->next;
	result = target;
	delete temp;
	temp = nullptr;
	return true;
}
template<class ItemType>
bool List342<ItemType>::Peek(ItemType target, ItemType& result) const
{
	if (isEmpty())
	{
		cout << "The List is Empty." << endl;
		return false;
	}

	if (*head_->data == target)
	{
		result = target;
		return true;
	}
	Node* p_node = head_;
	while ((p_node->next != nullptr) && (*(p_node->next)->data < target))
	{
		p_node = p_node->next;
	}
	if ((p_node->next == nullptr) || (*(p_node->next)->data != target))
	{
		return false;
	}
	result = target;
	return true;
}
template<class ItemType>
bool List342<ItemType>::isEmpty() const
{
	if (head_ == nullptr)
	{
		return true;
	}
	return false;
}
template<class ItemType>
void List342<ItemType>::DeleteList()
{
	while (head_ != nullptr)
	{
		ItemType answer = *head_->data;
		ItemType result;
		head_ = head_->next;
		Remove(answer, result);
	}
}
template<class ItemType>
bool List342<ItemType>::Merge(List342& list1)
{
	if (*this == list1)
	{
		return false;
	}
	Node* p_node = head_;
	while (list1.head_ != nullptr && p_node != nullptr)
	{
		// If the next node is equal to nullptr
		if (p_node->next == nullptr)
		{
			p_node->next = list1.head_;
			list1.head_ = nullptr;
			return true;
		}
		// If both are equal to each other, delete the list1 duplicate and make point to the next one
		else if (*head_->data == *list1.head_->data)
		{
			Node* temp = list1.head_;
			list1.head_ = list1.head_->next;
			delete temp;
			temp = nullptr;
		}
		// If the current p_node value is greater than the list1 current value, then move previous p_node back and set the current p_node to list1 current
		else if (*head_->data > *list1.head_->data)
		{
			head_ = list1.head_;
			list1.head_ = list1.head_->next;
			head_->next = p_node;
			p_node = head_;
		}
		// If the next value of p_node is the same as head, it will delete the duplicatee
		else if (*p_node->next->data == *list1.head_->data)
		{
			Node* temp = p_node->next;
			temp = list1.head_;
			list1.head_ = list1.head_->next;
			delete temp;
			temp = nullptr;
		}
		// If the next node value is greater than the current list1 value, then put the list1 node ahead of the next node
		else if (*p_node->next->data > *list1.head_->data)
		{
			Node* temp = p_node->next;
			p_node->next = list1.head_;
			list1.head_ = list1.head_->next;
			p_node = p_node->next;
			p_node->next = temp;
		}
		else
		{
			p_node = p_node->next;
		}
	}
	return true;
}

template<class ItemType>
List342<ItemType> List342<ItemType>::operator+(const List342<ItemType>& list) const
{
	List342<ItemType> temp = list;
	List342<ItemType> temp2 = *this;
	temp2.Merge(temp);
	return temp2;
}
template<class ItemType>
List342<ItemType> List342<ItemType>::operator+=(const List342<ItemType>& list)
{
	List342<ItemType> temp = list;
	this->Merge(temp);
	return *this;
}

template<class ItemType>
bool List342<ItemType>::operator==(const List342& list) const
{
	if (this->isEmpty() && list.isEmpty())
	{
		return false;
	}
	Node* pointer_this = head_;
	Node* pointer_list = list.head_;
	
	while (pointer_this != nullptr && pointer_list != nullptr)
	{
		if (*pointer_this->data != *pointer_list->data)
		{
			return false;
		}
		pointer_this = pointer_this->next;
		pointer_list = pointer_list->next;
	}
	return true;
}

template<class ItemType>
bool List342<ItemType>::operator!=(const List342& list) const
{
	if (this->isEmpty() && list.isEmpty())
	{
		return false;
	}
	Node* pointer_this = head_;
	Node* pointer_list = list.head_;

	while (pointer_this != nullptr && pointer_list != nullptr)
	{
		if (*pointer_this->data == *pointer_list->data)
		{
			return true;
		}
		pointer_this = pointer_this->next;
		pointer_list = pointer_list->next;
	}
	return false;
}

template<class ItemType>
List342<ItemType>& List342<ItemType>::operator=(const List342<ItemType>& list)
{
	// No duplicates
	if (this == &list)
	{
		return *this;
	}

	while (head_ != nullptr)
	{
		ItemType answer = *head_->data;
		ItemType result;
		head_ = head_->next;
		Remove(answer, result);
	}

	Node* s_node = nullptr;
	Node* d_node = nullptr;
	Node* ins_node = nullptr;
	if (list.head_ == nullptr)
	{
		return *this;
	}
	d_node = new Node;
	d_node->data = list.head_->data;
	this->head_ = d_node;
	s_node = list.head_->next;
	while (s_node != nullptr)
	{
		ins_node = new Node;
		ins_node->data = s_node->data;
		d_node->next = ins_node;
		d_node = d_node->next;
		s_node = s_node->next;
	}
	return *this;
}
#endif



