/*
	CSS 342 B - Data Structures, Algorithms, and Discrete Mathematics I
	Name: Terry Tran
	Program 3: Linked List - Child class
	Description: 
	This Child class is for the students. It inputs students' first and last names, as well as their age. 
	From this class, the list of students is created in the List342 class when functions of the List342
	are called in the driver. 
*/
#ifndef CHILD_H
#define CHILD_H
#include <string>
#include <iostream>
using namespace std;
class Child
{
public:
	// Constructors
	Child();
	Child(string first, string last, int age);
	Child(const Child& child);
	~Child();
	// Getters-Setters
	string getFirstName() const;
	string getLastName() const;
	int getAge() const;
	// Operator Overloads
	bool operator<(const Child& child) const;
	bool operator>(const Child& child) const;
	bool operator==(const Child& child) const;
	bool operator!=(const Child& child) const;
	Child operator=(const Child& child);

	friend ostream& operator<<(ostream& out_stream, const Child& child);
	friend istream& operator>>(istream& in_stream, Child& child);

private:
	// Pricate Data Types
	string first_name_ = "";
	string last_name_ = "";
	int age_ = 0;
};
#endif