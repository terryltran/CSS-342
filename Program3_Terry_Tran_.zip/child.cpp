/*
* This is the implementation of the Child class seen in "child.h"
*/
#include "child.h"
Child::Child()
{
}

Child::Child(string first, string last, int age)
{
	first_name_ = first;
	last_name_ = last;
	age_ = age;
}

Child::Child(const Child& child) // Copy Constructor
{
	first_name_ = child.first_name_;
	last_name_ = child.last_name_;
	age_ = child.age_;
}

Child::~Child()
{
}

string Child::getFirstName() const
{
	return first_name_;
}

string Child::getLastName() const
{
	return last_name_;
}

int Child::getAge() const
{
	return age_;
}

bool Child::operator<(const Child& child) const
{
	if (last_name_ < child.getLastName())
	{
		return true;
	}
	else if (last_name_ == child.getLastName())
	{
		if (first_name_ == child.getFirstName()) 
		{
			if (age_ < child.getAge())
			{
				return true;
			}
		}
		else if (first_name_ < child.getFirstName())
		{
			return true;
		}
	}
	return false; 
}

bool Child::operator>(const Child& child) const
{
	if (last_name_ > child.getLastName())
	{
		return true;
	}
	else if (last_name_ == child.getLastName())
	{
		if (first_name_ == child.getFirstName())
		{
			if (age_ > child.getAge())
			{
				return true;
			}
		}
		else if (first_name_ > child.getFirstName())
		{
			return true;
		}
	}
	return false;
}

bool Child::operator==(const Child& child) const
{
	if ((this->last_name_ == child.getLastName()) && (this->first_name_ == child.getFirstName()) && (this->age_ == child.getAge()))
	{
		return true;
	}
	return false;
}

bool Child::operator!=(const Child& child) const
{
	if ((this->last_name_ != child.getLastName()) || (this->first_name_ != child.getFirstName()) || (this->age_ != child.getAge()))
	{
		return true;
	}
	return false;
}

Child Child::operator=(const Child& child)
{
	this->first_name_ = child.getFirstName();
	this->last_name_ = child.getLastName();
	this->age_ = child.getAge();
	return *this;
}

ostream& operator<<(ostream& out_stream, const Child& child)
{
	out_stream << child.getFirstName() << child.getLastName() << child.getAge();
	return out_stream;
}

istream& operator>>(istream& in_stream, Child& child)
{
	in_stream >> child.first_name_ >> child.last_name_ >> child.age_;
	return in_stream;
}
