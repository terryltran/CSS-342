#include <iostream>

#include "TimeSpan.h"

using namespace std;

int main()
{
    TimeSpan dur1(1, 1, 0), dur2(0, -6, 0), dur3(0, 0, 0), dur4(0, 0, 1);
    TimeSpan dur5(-6, -5, 4.5), dur6(6.5, 123.78, 4.9), dur7(-1, -1, 1);
    TimeSpan dur8, dur9;

    dur8 = dur1 + dur2;
    
    cout << "Give a time: ";
    cin >> dur9;

    cout << dur1 << endl;
    cout << dur2 << endl;
    cout << dur3 << endl;
    cout << dur4 << endl;
    cout << dur5 << endl;
    cout << dur6 << endl;
    cout << dur7 << endl;
    cout << dur8 << endl;
    cout << dur9 << endl;

    dur8 -= dur1;
    cout << dur8 << endl;

    dur9 = dur5 - dur6;
    cout << dur9 << endl;

    dur1 += dur7;
    cout << dur1 << endl;

    dur5 = -dur5;
    cout << dur5 << endl;

    if (dur1 == dur4)
    {
        cout << "The durations are the same." << endl;
    }
    else
    {
        cout << "The durations are not the same." << endl;
    }

    if (dur1 != dur2)
    {
        cout << "The durations are not the same." << endl;
    }
    else
    {
        cout << "The durations are the same." << endl;
    }
}

