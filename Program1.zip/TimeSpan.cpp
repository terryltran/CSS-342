#include <iostream>
#include <string>

#include "TimeSpan.h"

using namespace std;

TimeSpan::TimeSpan()
{
}

TimeSpan::~TimeSpan()
{
}

TimeSpan::TimeSpan(double seconds)
{
	double hours = 0;
	double minutes = 0;
	CalculateAll(hours, minutes, seconds);
}

TimeSpan::TimeSpan(double minutes, double seconds)
{
	double hours = 0;
	CalculateAll(hours, minutes, seconds);
}

TimeSpan::TimeSpan(double hours, double minutes, double seconds)
{
	CalculateAll(hours, minutes, seconds);
}

int TimeSpan::getHours() const
{
	return hours_;
}

int TimeSpan::getMinutes() const
{
	return minutes_;
}

int TimeSpan::getSeconds() const
{
	return seconds_;
}

bool TimeSpan::setTime(int hours, int minutes, int seconds)
{
	CalculateAll(hours, minutes, seconds);
	return true;
}

TimeSpan TimeSpan::operator+(const TimeSpan& time)
{
	int hours = (hours_ + time.getHours());
	int minutes = (minutes_ + time.getMinutes());
	int seconds = (seconds_ + time.getSeconds());
	return TimeSpan(hours, minutes, seconds);
}

TimeSpan& TimeSpan::operator+=(const TimeSpan& time)
{
	hours_ = hours_ + time.getHours();
	minutes_ = minutes_ + time.getMinutes();
	seconds_ = seconds_ + time.getSeconds();
	CalculateAll(hours_, minutes_, seconds_);
	return *this;
}

TimeSpan TimeSpan::operator-(const TimeSpan& time)
{
	int hours = (hours_ - time.getHours());
	int minutes = (minutes_ - time.getMinutes());
	int seconds = (seconds_ - time.getSeconds());
	return TimeSpan(hours, minutes, seconds);
}

TimeSpan& TimeSpan::operator-=(const TimeSpan& time)
{
	hours_ = hours_ - time.getHours();
	minutes_ = minutes_ - time.getMinutes();
	seconds_ = seconds_ - time.getSeconds();
	CalculateAll(hours_, minutes_, seconds_);
	return *this;
}

TimeSpan TimeSpan::operator-()
{
	hours_ = -hours_;
	minutes_ = -minutes_;
	seconds_ = -seconds_;
	return TimeSpan(hours_, minutes_, seconds_);
}

bool TimeSpan::operator==(const TimeSpan& time)
{
	return ((hours_ == time.getHours()) && (minutes_ == time.getMinutes()) && (seconds_ == time.getSeconds()));
}

bool TimeSpan::operator!=(const TimeSpan& time)
{
	return ((hours_ != time.getHours()) || (minutes_ != time.getMinutes()) || (seconds_ != time.getSeconds()));
}

ostream& operator<<(ostream& out_stream, TimeSpan& time)
{
	out_stream << "Hours: " << time.getHours() << ", Minutes: " << time.getMinutes() << ", Seconds: " << time.getSeconds();
	return out_stream;
}

istream& operator>>(istream& in_stream, TimeSpan& time)
{
	in_stream >> time.hours_ >> time.minutes_ >> time.seconds_;
	time.CalculateAll(time.hours_, time.minutes_, time.seconds_);
	return in_stream;
}

void TimeSpan::CalculateAll(double hours, double minutes, double seconds)
{
	seconds = round(seconds);
	temp_hours_ = hours * 3600;
	temp_minutes_ = minutes * 60;
	total_seconds_ = temp_hours_ + temp_minutes_ + seconds;

	hours_ = total_seconds_ / 3600;
	total_seconds_ = total_seconds_ % 3600;
	minutes_ = total_seconds_ / 60;
	seconds_ = total_seconds_ % 60;
}
