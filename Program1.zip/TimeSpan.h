#pragma once
#include <iostream>

using namespace std;

class TimeSpan
{
public:
	//constructors
	TimeSpan();
	~TimeSpan();
	TimeSpan(double seconds);
	TimeSpan(double minutes, double seconds);
	TimeSpan(double hours, double minutes, double seconds);


	//getters-setters
	int getHours() const;
	int getMinutes() const;
	int getSeconds() const;
	bool setTime(int hours, int minutes, int seconds);

	//operators
	TimeSpan operator+(const TimeSpan& time);
	TimeSpan& operator+=(const TimeSpan& time);

	TimeSpan operator-(const TimeSpan& time);
	TimeSpan& operator-=(const TimeSpan& time);
	TimeSpan operator-();

	bool operator==(const TimeSpan& time);
	bool operator!=(const TimeSpan& time);
	
	friend ostream& operator<<(ostream& out_stream, TimeSpan& time);
	friend istream& operator>>(istream& in_stream, TimeSpan& time);
	


private:
	//data types
	double seconds_ = 0;
	double minutes_ = 0;
	double hours_ = 0;
	
	//used for CalcAll function (Action)
	int temp_hours_ = 0;
	int temp_minutes_ = 0;
	int total_seconds_ = 0;

	//function calculates and rounds the time correctly 
	//to be changed into integers for setTime
	void CalculateAll(double hours, double minutes, double seconds);
};
