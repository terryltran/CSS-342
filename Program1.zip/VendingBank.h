#pragma once
#include <string>

using namespace std;

class VendingBank
{
public:
	//constructors
	VendingBank();
	VendingBank(int id);
	~VendingBank();

	//getters-setters
	int getVendingBankID() const;
	int getSnackPrice() const;
	bool setVendingBankID(int id);
	bool setSnackPrice(int price);

	//Actions
	void Deposit(double coins, string coin_type);
	bool CoinCheck(string coin_type);
	void EjectCoin();
	void GiveChange(double price, double deposit);

	//Operators
	VendingBank operator+(const VendingBank& bank);

private:
	//data types
	double bank_funds_;
	const string kAcceptedCoins_[4] = { "Penny", "Nickel", "Dime", "Quarter" };
};